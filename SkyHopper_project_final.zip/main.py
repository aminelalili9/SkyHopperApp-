
# Sky Hopper - configured for: 
#   App Name: Sky Hopper
#   Developer: Falcon Games
#   Ads: Banner (user provided) + Interstitial (test ID included — replace with your Interstitial Ad Unit ID)

# main.py - Sky Hopper (Kivy)
from kivy.app import App
from kivy.uix.widget import Widget
from kivy.clock import Clock
from kivy.graphics import Rectangle, Color
from kivy.core.window import Window
from kivy.uix.image import Image
from kivy.properties import NumericProperty, StringProperty
from kivy.utils import platform
import random, os

Window.size = (400, 609)
WIDTH, HEIGHT = Window.size

class Pipe:
    def __init__(self, x, gap_y, width=70, gap=150):
        self.x = x
        self.gap_y = gap_y
        self.width = width
        self.gap = gap

class GameWidget(Widget):
    score = NumericProperty(0)
    level = NumericProperty(1)
    status_text = StringProperty("Tap to start")

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.bird_x = 100
        self.bird_y = HEIGHT/2
        self.bird_radius = 20
        self.velocity = 0
        self.jump_power = -9
        self.gravity = 0.5
        self.pipe_speed = 4
        self.pipe_gap = 150
        self.pipe_width = 70
        self.pipes = []
        self.spawn_pipe()
        self.running = False
        self.level_up_score = 5
        self.max_level = 10
        self.frame = 0
        Clock.schedule_interval(self.update, 1.0/60.0)

    def start(self):
        self.running = True
        self.score = 0
        self.level = 1
        self.velocity = 0
        self.bird_y = HEIGHT/2
        self.pipes = []
        self.pipe_speed = 4
        self.pipe_gap = 150
        self.spawn_pipe()

    def spawn_pipe(self):
        gap_y = random.randint(120, HEIGHT-200)
        x = WIDTH + 100
        self.pipes.append(Pipe(x,gap_y,width=self.pipe_width,gap=self.pipe_gap))

    def on_touch_down(self, touch):
        if not self.running:
            self.start()
        self.velocity = self.jump_power

    def update(self, dt):
        if not self.running:
            self.canvas.clear()
            self.draw()
            return
        self.velocity += self.gravity
        self.bird_y += self.velocity

        remove_list = []
        for pipe in self.pipes:
            pipe.x -= self.pipe_speed
            if pipe.x + pipe.width < 0:
                remove_list.append(pipe)
                self.score += 1
        for r in remove_list:
            if r in self.pipes:
                self.pipes.remove(r)
        if len(self.pipes) == 0 or self.pipes[-1].x < WIDTH - 200:
            self.spawn_pipe()

        if (self.bird_y - self.bird_radius < 0 or self.bird_y + self.bird_radius > HEIGHT):
            self.game_over()
        else:
            for pipe in self.pipes:
                if (self.bird_x + self.bird_radius > pipe.x and self.bird_x - self.bird_radius < pipe.x + pipe.width):
                    if (self.bird_y - self.bird_radius < pipe.gap_y or self.bird_y + self.bird_radius > pipe.gap_y + pipe.gap):
                        self.game_over()
                        break

        new_level = min(self.max_level, 1 + self.score // self.level_up_score)
        if new_level != self.level:
            self.level = new_level
            self.on_level_up()

        self.canvas.clear()
        self.draw()

    def on_level_up(self):
        self.pipe_speed += 0.5
        if self.pipe_gap > 90:
            self.pipe_gap -= 10
        self.status_text = f"Level {self.level}"
        Clock.schedule_once(lambda dt: setattr(self, 'status_text', ''), 1.5)

    def game_over(self):
        self.running = False
        self.status_text = f"Game Over! Score: {self.score}"
        try:
            App = __import__('kivy.app').app.App
            app = App.get_running_app()
            if hasattr(app, 'show_interstitial'):
                app.show_interstitial()
        except Exception:
            pass

    def draw(self):
        # background
        with self.canvas:
            Rectangle(source=os.path.join('assets','background.png'), pos=(0,0), size=(WIDTH, HEIGHT))
        # pipes
        with self.canvas:
            for pipe in self.pipes:
                Rectangle(source=os.path.join('assets','pipe.png'), pos=(pipe.x, pipe.gap_y + pipe.gap), size=(pipe.width, HEIGHT - (pipe.gap_y + pipe.gap)))
                Rectangle(source=os.path.join('assets','pipe.png'), pos=(pipe.x, 0), size=(pipe.width, pipe.gap_y))
        # bird (simple frame animation)
        bird_frame = (self.frame // 6) % 3 + 1
        bird_src = os.path.join('assets', f'bird{bird_frame}.png')
        with self.canvas:
            Rectangle(source=bird_src, pos=(self.bird_x - 24, self.bird_y - 24), size=(48,48))
        self.frame += 1

class SkyHopperApp(App):
    def build(self):
        self.game = GameWidget()
        # create banner on android
        if platform == 'android':
            self.create_banner()
        return self.game

    def create_banner(self):
        # App metadata
        self.app_name = 'Sky Hopper'
        self.developer = 'Falcon Games'

        # This runs only on Android when packaged with the proper gradle deps.
        try:
            from jnius import autoclass
            from android.runnable import run_on_ui_thread
        except Exception as e:
            print('banner: not on android or jnius missing', e)
            return

        AdView = autoclass('com.google.android.gms.ads.AdView')
        AdSize = autoclass('com.google.android.gms.ads.AdSize')
        AdRequestBuilder = autoclass('com.google.android.gms.ads.AdRequest$Builder')
        PythonActivity = autoclass('org.kivy.android.PythonActivity')
        LinearLayout = autoclass('android.widget.LinearLayout')
        ViewGroupLayoutParams = autoclass('android.view.ViewGroup$LayoutParams')
        Gravity = autoclass('android.view.Gravity')

        activity = PythonActivity.mActivity

        @run_on_ui_thread
        def _add_banner():
            linear = LinearLayout(activity)
            linear.setOrientation(1)
            params = ViewGroupLayoutParams(ViewGroupLayoutParams.MATCH_PARENT, ViewGroupLayoutParams.WRAP_CONTENT)
            linear.setLayoutParams(params)
            linear.setGravity(Gravity.BOTTOM)
            ad_view = AdView(activity)
            ad_view.setAdSize(AdSize.BANNER)
            ad_view.setAdUnitId("ca-app-pub-6449165783660039/6580184046")  # your Ad Unit ID
            linear.addView(ad_view)
            activity.addContentView(linear, params)
            ad_req = AdRequestBuilder().build()
            ad_view.loadAd(ad_req)

        _add_banner()



    def create_interstitial(self):
        # Interstitial setup (works on Android when packaged). Uses Google's TEST interstitial ID by default.
        try:
            from jnius import autoclass
            from android.runnable import run_on_ui_thread
        except Exception as e:
            print('interstitial: not on android or jnius missing', e)
            return

        InterstitialAd = autoclass('com.google.android.gms.ads.interstitial.InterstitialAd')
        InterstitialAdLoadCallback = autoclass('com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback')
        AdRequestBuilder = autoclass('com.google.android.gms.ads.AdRequest$Builder')
        PythonActivity = autoclass('org.kivy.android.PythonActivity')

        activity = PythonActivity.mActivity
        # NOTE: replace this test ID with your real Interstitial Ad Unit ID later
        interstitial_unit_id = "ca-app-pub-3940256099942544/1033173712"

        # Loading interstitial is asynchronous and requires Android lifecycle handling;
        # for simplicity this function demonstrates intent but may need refinement.
        try:
            @run_on_ui_thread
            def _load():
                from jnius import cast, autoclass
                InterstitialAd = autoclass('com.google.android.gms.ads.interstitial.InterstitialAd')
                InterstitialAdLoadCallback = autoclass('com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback')
                # The full interop requires a Java callback class; complex to do inline here.
                print('interstitial: placeholder - loaded (demo)')

            _load()
        except Exception as ex:
            print('interstitial load failed', ex)

    def show_interstitial(self):
        # Placeholder: in a packaged APK this should show an interstitial if loaded.
        try:
            print('show_interstitial: (placeholder) would show interstitial on Android if loaded.')
        except Exception as e:
            print('show_interstitial error', e)

if __name__ == '__main__':
    SkyHopperApp().run()
